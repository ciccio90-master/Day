import WidgetKit
import SwiftUI

private let groupID = "group.com.example.day"
private let storageKey = "day.events.v1"

struct WidgetEvent: Codable, Identifiable {
    var id: UUID
    var title: String
    var date: Date
    var category: String
}

struct DAYEntry: TimelineEntry {
    let date: Date
    let events: [WidgetEvent]
}

struct DAYProvider: TimelineProvider {
    func placeholder(in context: Context) -> DAYEntry {
        DAYEntry(date: .now, events: [WidgetEvent(id: UUID(), title: "Allenamento", date: .now, category: "PALESTRA")])
    }

    func getSnapshot(in context: Context, completion: @escaping (DAYEntry) -> Void) {
        completion(DAYEntry(date: .now, events: loadEvents()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<DAYEntry>) -> Void) {
        let entry = DAYEntry(date: .now, events: loadEvents())
        completion(Timeline(entries: [entry], policy: .after(.now.addingTimeInterval(15 * 60))))
    }

    private func loadEvents() -> [WidgetEvent] {
        guard let data = UserDefaults(suiteName: groupID)?.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([StoredEvent].self, from: data) else { return [] }
        return decoded.compactMap { item in
            let date = item.nextDate()
            guard date >= .now else { return nil }
            return WidgetEvent(id: item.id, title: item.title, date: date, category: item.category)
        }.sorted { $0.date < $1.date }.prefix(4).map { $0 }
    }
}

private struct StoredEvent: Codable {
    var id: UUID
    var title: String
    var date: Date
    var category: String
    var repeatRule: String
    func nextDate() -> Date {
        guard let rule = ["Mai": 0, "Ogni settimana": 1, "Ogni anno": 2][repeatRule] else { return date }
        if rule == 0 || date >= .now { return date }
        if rule == 1 {
            let days = Calendar.current.dateComponents([.day], from: date, to: .now).day ?? 0
            return Calendar.current.date(byAdding: .weekOfYear, value: max(1, (days + 6) / 7), to: date) ?? date
        }
        var parts = Calendar.current.dateComponents([.month, .day, .hour, .minute], from: date)
        parts.year = Calendar.current.component(.year, from: .now)
        let candidate = Calendar.current.date(from: parts) ?? date
        if candidate >= .now { return candidate }
        parts.year! += 1
        return Calendar.current.date(from: parts) ?? date
    }
}

struct DAYWidgetView: View {
    let entry: DAYEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text("DAY.").font(.system(size: 17, weight: .black))
                Spacer()
                Text("AGENDA").font(.system(size: 8, weight: .bold)).foregroundStyle(.secondary)
            }
            if entry.events.isEmpty {
                Spacer()
                Text("Nessun impegno in programma").font(.system(size: 12)).foregroundStyle(.secondary)
                Spacer()
            } else {
                ForEach(entry.events) { event in
                    HStack(spacing: 8) {
                        Text(event.date.formatted(date: .omitted, time: .shortened))
                            .font(.system(size: 10, weight: .medium, design: .rounded))
                            .foregroundStyle(.secondary)
                            .frame(width: 43, alignment: .leading)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(event.title).font(.system(size: 11, weight: .semibold)).lineLimit(1)
                            Text(event.category.uppercased()).font(.system(size: 7, weight: .bold)).foregroundStyle(.secondary)
                        }
                    }
                }
                Spacer(minLength: 0)
            }
        }
        .padding(14)
        .containerBackground(.black, for: .widget)
        .foregroundStyle(.white)
    }
}

@main
struct DAYWidget: Widget {
    let kind = "DAYWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: DAYProvider()) { entry in
            DAYWidgetView(entry: entry)
        }
        .configurationDisplayName("DAY. Agenda")
        .description("I tuoi prossimi impegni, a colpo d'occhio.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryRectangular, .accessoryInline])
    }
}
