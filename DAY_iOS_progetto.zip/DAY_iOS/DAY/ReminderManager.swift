import Foundation
import UserNotifications

final class ReminderManager {
    static let shared = ReminderManager()
    private init() {}

    func requestPermission() async {
        _ = try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
    }

    func schedule(for event: DayEvent) {
        guard event.reminderMinutes > 0,
              let occurrence = event.nextDate(),
              let fireDate = Calendar.current.date(byAdding: .minute, value: -event.reminderMinutes, to: occurrence),
              fireDate > .now else { return }

        let content = UNMutableNotificationContent()
        content.title = event.title
        content.body = "Hai un impegno in programma."
        content.sound = .default

        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: fireDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        let request = UNNotificationRequest(identifier: event.id.uuidString, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    func cancel(for event: DayEvent) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [event.id.uuidString])
    }
}
