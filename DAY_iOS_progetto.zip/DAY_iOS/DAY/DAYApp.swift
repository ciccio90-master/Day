import SwiftUI

@main
struct DAYApp: App {
    @StateObject private var store = EventStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
                .task { await ReminderManager.shared.requestPermission() }
        }
    }
}
