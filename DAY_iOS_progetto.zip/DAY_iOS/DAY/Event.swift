import Foundation

enum EventCategory: String, CaseIterable, Codable, Identifiable {
    case palestra = "Palestra"
    case lavoro = "Lavoro"
    case personale = "Personale"
    case compleanno = "Compleanno"
    case cena = "Cena / Uscita"
    case altro = "Altro"
    var id: String { rawValue }
}

enum EventRepeat: String, CaseIterable, Codable, Identifiable {
    case never = "Mai"
    case weekly = "Ogni settimana"
    case yearly = "Ogni anno"
    var id: String { rawValue }
}

struct DayEvent: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var date: Date
    var category: EventCategory
    var repeatRule: EventRepeat = .never
    var reminderMinutes: Int = 0
    var notes: String = ""

    var displayDate: String {
        date.formatted(date: .abbreviated, time: .omitted)
    }

    func nextDate(after now: Date = .now) -> Date? {
        switch repeatRule {
        case .never:
            return date >= now ? date : nil
        case .weekly:
            if date >= now { return date }
            let cal = Calendar.current
            let days = cal.dateComponents([.day], from: cal.startOfDay(for: date), to: cal.startOfDay(for: now)).day ?? 0
            let weeks = max(1, (days + 6) / 7)
            return cal.date(byAdding: .weekOfYear, value: weeks, to: date)
        case .yearly:
            let cal = Calendar.current
            let parts = cal.dateComponents([.month, .day, .hour, .minute], from: date)
            let currentYear = cal.component(.year, from: now)
            var candidate = DateComponents()
            candidate.year = currentYear
            candidate.month = parts.month
            candidate.day = parts.day
            candidate.hour = parts.hour
            candidate.minute = parts.minute
            let thisYear = cal.date(from: candidate) ?? date
            if thisYear >= now { return thisYear }
            candidate.year = currentYear + 1
            return cal.date(from: candidate)
        }
    }
}
