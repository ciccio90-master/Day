import Foundation
import WidgetKit

@MainActor
final class EventStore: ObservableObject {
    @Published private(set) var events: [DayEvent] = []
    private let groupID = "group.com.example.day"
    private let storageKey = "day.events.v1"

    init() { load() }

    private var sharedDefaults: UserDefaults? { UserDefaults(suiteName: groupID) }

    func load() {
        guard let data = sharedDefaults?.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([DayEvent].self, from: data) else {
            events = []
            return
        }
        events = decoded
    }

    func add(_ event: DayEvent) {
        events.append(event)
        save()
        ReminderManager.shared.schedule(for: event)
    }

    func delete(_ event: DayEvent) {
        events.removeAll { $0.id == event.id }
        ReminderManager.shared.cancel(for: event)
        save()
    }

    func save() {
        events.sort { ($0.nextDate() ?? $0.date) < ($1.nextDate() ?? $1.date) }
        if let data = try? JSONEncoder().encode(events) {
            sharedDefaults?.set(data, forKey: storageKey)
        }
        WidgetCenter.shared.reloadAllTimelines()
    }

    func upcoming(from now: Date = .now) -> [(DayEvent, Date)] {
        events.compactMap { event in
            guard let date = event.nextDate(after: now) else { return nil }
            return (event, date)
        }.sorted { $0.1 < $1.1 }
    }
}
