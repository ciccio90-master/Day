import SwiftUI

struct AddEventView: View {
    @Environment(\.dismiss) private var dismiss
    let onSave: (DayEvent) -> Void

    @State private var title = ""
    @State private var date = Date.now
    @State private var category: EventCategory = .palestra
    @State private var repeatRule: EventRepeat = .never
    @State private var reminder = 0
    @State private var notes = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("IMPEGNO") {
                    TextField("Es. Allenamento, cena, compleanno", text: $title)
                    DatePicker("Data e ora", selection: $date)
                    Picker("Categoria", selection: $category) {
                        ForEach(EventCategory.allCases) { item in Text(item.rawValue).tag(item) }
                    }
                }
                Section("RIPETIZIONE E PROMEMORIA") {
                    Picker("Ripeti", selection: $repeatRule) {
                        ForEach(EventRepeat.allCases) { item in Text(item.rawValue).tag(item) }
                    }
                    Picker("Avvisami", selection: $reminder) {
                        Text("Nessun promemoria").tag(0)
                        Text("5 minuti prima").tag(5)
                        Text("15 minuti prima").tag(15)
                        Text("30 minuti prima").tag(30)
                        Text("1 ora prima").tag(60)
                        Text("1 giorno prima").tag(1440)
                    }
                }
                Section("NOTE") {
                    TextField("Aggiungi una nota (facoltativo)", text: $notes, axis: .vertical)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Nuovo impegno")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annulla") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Salva") {
                        onSave(DayEvent(title: title.trimmingCharacters(in: .whitespacesAndNewlines),
                                        date: date, category: category, repeatRule: repeatRule,
                                        reminderMinutes: reminder, notes: notes))
                        dismiss()
                    }.disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
        .tint(.white)
    }
}
