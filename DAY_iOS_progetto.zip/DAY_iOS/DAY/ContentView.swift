import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: EventStore
    @State private var showingAdd = false
    @State private var selectedTab = 0

    private let black = Color.black
    private let card = Color(white: 0.12)

    var body: some View {
        ZStack {
            black.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                if selectedTab == 0 { todayView }
                else { calendarView }
                Spacer(minLength: 8)
                bottomBar
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)
        }
        .sheet(isPresented: $showingAdd) {
            AddEventView { store.add($0) }
                .preferredColorScheme(.dark)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("DAY.").font(.system(size: 29, weight: .black, design: .rounded))
                Spacer()
                Text(Date.now.formatted(.dateTime.weekday(.wide).day().month(.wide)).uppercased())
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.gray)
            }
            Text(selectedTab == 0 ? "I tuoi impegni." : "Il tuo calendario.")
                .font(.system(size: 27, weight: .bold))
                .tracking(-0.8)
            Text("Tutto quello che conta, in un solo posto.")
                .font(.system(size: 13))
                .foregroundStyle(.gray)
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.bottom, 24)
    }

    private var todayView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 12) {
                    statCard(title: "OGGI", value: "\(todayEvents.count)", subtitle: "Impegni")
                    statCard(title: "PROSSIMI", value: "\(store.upcoming().count)", subtitle: "In agenda")
                }
                Text("OGGI")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.gray)
                    .padding(.top, 8)
                if todayEvents.isEmpty {
                    Text("Nessun impegno per oggi.")
                        .foregroundStyle(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(18)
                        .background(card, in: RoundedRectangle(cornerRadius: 16))
                } else {
                    ForEach(todayEvents) { event in eventRow(event, date: event.date) }
                }
                Text("PROSSIMI IMPEGNI")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.gray)
                    .padding(.top, 8)
                ForEach(store.upcoming().filter { !Calendar.current.isDateInToday($0.1) }.prefix(5), id: \.0.id) { event, date in
                    eventRow(event, date: date)
                }
            }
            .padding(.bottom, 12)
        }
    }

    private var calendarView: some View {
        List {
            ForEach(store.upcoming(), id: \.0.id) { event, date in
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(event.title).font(.system(size: 15, weight: .semibold))
                        Text("\(date.formatted(date: .complete, time: .omitted)) · \(event.category.rawValue)")
                            .font(.system(size: 11)).foregroundStyle(.gray)
                    }
                    Spacer()
                    Text(date.formatted(date: .omitted, time: .shortened))
                        .foregroundStyle(.white.opacity(0.8))
                }
                .listRowBackground(card)
                .swipeActions {
                    Button(role: .destructive) { store.delete(event) } label: { Label("Elimina", systemImage: "trash") }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .listStyle(.plain)
    }

    private var todayEvents: [DayEvent] {
        store.events.filter { Calendar.current.isDate($0.date, inSameDayAs: .now) }.sorted { $0.date < $1.date }
    }

    private func statCard(title: String, value: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.system(size: 9, weight: .bold)).foregroundStyle(.gray)
            Text(value).font(.system(size: 28, weight: .bold, design: .rounded))
            Text(subtitle).font(.system(size: 11)).foregroundStyle(.gray)
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .background(card, in: RoundedRectangle(cornerRadius: 16))
    }

    private func eventRow(_ event: DayEvent, date: Date) -> some View {
        HStack(spacing: 12) {
            Text(date.formatted(date: .omitted, time: .shortened))
                .font(.system(size: 12, weight: .medium, design: .rounded))
                .foregroundStyle(.gray)
                .frame(width: 54, alignment: .leading)
            VStack(alignment: .leading, spacing: 4) {
                Text(event.title).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                Text(event.category.rawValue.uppercased())
                    .font(.system(size: 9, weight: .bold)).foregroundStyle(.gray)
            }
            Spacer()
            Button { store.delete(event) } label: {
                Image(systemName: "xmark").font(.system(size: 10, weight: .bold)).foregroundStyle(.gray)
            }
        }
        .padding(15)
        .background(card, in: RoundedRectangle(cornerRadius: 15))
    }

    private var bottomBar: some View {
        HStack {
            Button { selectedTab = 0 } label: {
                Image(systemName: "house").foregroundStyle(selectedTab == 0 ? .white : .gray)
            }
            Spacer()
            Button { selectedTab = 1 } label: {
                Image(systemName: "calendar").foregroundStyle(selectedTab == 1 ? .white : .gray)
            }
            Spacer()
            Button { showingAdd = true } label: {
                Image(systemName: "plus").font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.black).frame(width: 48, height: 42)
                    .background(.white, in: RoundedRectangle(cornerRadius: 13))
            }
            Spacer()
            Image(systemName: "bell").foregroundStyle(.gray)
            Spacer()
            Image(systemName: "gearshape").foregroundStyle(.gray)
        }
        .font(.system(size: 19, weight: .medium))
        .padding(.vertical, 12)
    }
}
