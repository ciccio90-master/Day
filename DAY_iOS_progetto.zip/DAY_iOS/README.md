# DAY. — progetto iOS iniziale

App agenda indipendente per iPhone, con interfaccia bianco/nera, categorie, ricorrenze, notifiche locali e widget WidgetKit.

## Cosa include
- Inserimento ed eliminazione degli impegni
- Categorie: palestra, lavoro, personale, compleanno, cena/uscita, altro
- Ricorrenza settimanale e annuale
- Promemoria locali
- Widget Home (piccolo/medio) e widget compatibili con il blocco schermo
- Archivio condiviso tra app e widget tramite App Group

## Requisiti
- Mac con Xcode 15 o successivo
- iOS 17 o successivo
- XcodeGen (`brew install xcodegen`)

## Aprire il progetto
1. Scompatta l'archivio.
2. Apri Terminale nella cartella `DAY_iOS`.
3. Esegui `xcodegen generate`.
4. Apri `DAY.xcodeproj` con Xcode.
5. In **Signing & Capabilities**, seleziona il tuo Team per entrambi i target.
6. Crea un App Group nel tuo account Apple Developer e sostituisci `group.com.example.day` in entrambi i file `.entitlements`, in `EventStore.swift` e `DAYWidget.swift`.
7. Sostituisci `com.example.day` e `com.example.day.widget` con identificatori bundle univoci, se necessario.
8. Seleziona il target DAY, collega un iPhone e premi Run.

## Prima della pubblicazione
Questo è uno starter project funzionante da completare e verificare in Xcode: servono firma, provisioning, icona, schermate App Store, privacy label, test su dispositivi reali e account Apple Developer. La sincronizzazione tra dispositivi non è inclusa: i dati sono locali e condivisi con il widget sullo stesso iPhone. Il widget si aggiorna secondo le finestre di aggiornamento consentite da iOS, non in tempo reale garantito.

## Nota tecnica
Il prototipo salva gli eventi in UserDefaults dell'App Group. Per un prodotto definitivo è consigliabile migrare a un database locale più robusto, aggiungere modifica eventi, gestione completa delle serie ricorrenti, ricerca, esportazione/backup e test di accessibilità.
